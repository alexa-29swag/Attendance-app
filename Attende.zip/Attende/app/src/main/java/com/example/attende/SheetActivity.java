package com.example.attende;

import androidx.appcompat.app.AppCompatActivity;
import com.example.attende.MyCalendar;

import android.content.Intent;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SheetActivity extends AppCompatActivity {
    private String className;
    private String subjectName;
    private TextView title;
    private TextView subtitle;
    private ImageButton back;
    private MyCalendar calendar;
    private TextView[] roll_tvs;
    private TextView[] name_tvs;
    private TextView[][] status_tvs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheet);

        // Initialize calendar
        calendar = new MyCalendar();

        showTable();
        className = getIntent().getStringExtra("className");
        subjectName = getIntent().getStringExtra("subjectName");
        setToolbar(className, subjectName);
        ImageButton generatePdfButton = findViewById(R.id.generatePdfButton);
        generatePdfButton.setOnClickListener(v -> generatePdf());
    }

    private void generatePdf() {
        // Create a new Document
        Document document = new Document();

        try {
            // Get the current date and time
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName = "Attendance_" + timeStamp + ".pdf";

            // Create directory if not exists
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/AttendancePDFs/");
            directory.mkdirs();

            // Create a new file to write the PDF to
            File file = new File(directory, fileName);
            FileOutputStream fos = new FileOutputStream(file);

            // Create a PdfWriter instance
            PdfWriter writer = PdfWriter.getInstance(document, fos);

            // Set custom page size (8.5x14 inches)
            Rectangle pageSize = new Rectangle(PageSize.LETTER.getHeight(), PageSize.LETTER.getWidth() * 2); // Swap width and height
            document.setPageSize(pageSize);

            // Open the document for writing
            document.open();

            // Add content to the document
            document.add(new Paragraph("Class: " + className));
            document.add(new Paragraph("Subject: " + subjectName));

            Calendar calendar = Calendar.getInstance(); // Get the current calendar instance
            int DAY_IN_MONTH = calendar.getActualMaximum(Calendar.DAY_OF_MONTH); // Get the number of days in the current month
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM"); // Date format for display
            document.add(new Paragraph("Date: " + dateFormat.format(calendar.getTime()))); // Display the date in yyyy-MM format

            // Capture TableLayout as Bitmap
            Bitmap bitmap = getBitmapFromView(findViewById(R.id.tableLayout));

            // Improve image quality by compressing with higher quality (100)
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();

            // Add the image to the PDF document
            Image image = Image.getInstance(byteArray);
            image.scaleToFit(PageSize.LETTER.getWidth(), PageSize.LETTER.getHeight()); // Scale image to fit page
            document.add(image);

            // Close the document
            document.close();

            // Show a message that PDF generation is successful
            String filePath = file.getAbsolutePath();
            Toast.makeText(this, "PDF generated successfully. Location: " + filePath, Toast.LENGTH_LONG).show();
            Log.d("PDF_PATH", "PDF saved to: " + filePath);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error generating PDF", Toast.LENGTH_SHORT).show();
            // Create directory if not exists
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/AttendancePDFs/");
            directory.mkdirs();
        }
    }




    private Bitmap getBitmapFromView(View view) {
        // Define a bitmap with the same size as the view
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);

        // Create a canvas using the bitmap
        Canvas canvas = new Canvas(bitmap);

        // Draw the view on the canvas
        view.draw(canvas);

        // Return the bitmap
        return bitmap;
    }

    private void setToolbar(String className, String subjectName) {
        title = findViewById(R.id.title_toolbar); // Initialize title TextView
        subtitle = findViewById(R.id.subtitle_toolbar); // Initialize subtitle TextView
        back = findViewById(R.id.back); // Initialize back ImageButton
        calendar = new MyCalendar(); // Initialize calendar MyCalendar

        title.setText(className);
        subtitle.setText(subjectName + " | " + calendar.getDate());

        back.setOnClickListener(v -> onBackPressed());
    }

    private void showTable() {
        DbHelper dbHelper = new DbHelper(this);
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        long[] idArray = getIntent().getLongArrayExtra("idArray");
        int[] rollArray = getIntent().getIntArrayExtra("rollArray");
        String[] nameArray = getIntent().getStringArrayExtra("nameArray");
        String month = getIntent().getStringExtra("month");

        int DAY_IN_MONTH = getDayInMonth(month);

        int rowSize = idArray.length + 1;

        TableRow[] rows = new TableRow[rowSize];
        roll_tvs = new TextView[rowSize];
        name_tvs = new TextView[rowSize];
        status_tvs = new TextView[rowSize][DAY_IN_MONTH + 1];

        // Header
        roll_tvs[0] = new TextView(this);
        roll_tvs[0].setText("Roll");
        roll_tvs[0].setTextColor(Color.BLACK);
        roll_tvs[0].setTypeface(null, Typeface.BOLD);
        roll_tvs[0].setPadding(16, 16, 16, 16); // Set padding here

        name_tvs[0] = new TextView(this);
        name_tvs[0].setText("Name");
        name_tvs[0].setTextColor(Color.BLACK);
        name_tvs[0].setTypeface(null, Typeface.BOLD);
        name_tvs[0].setPadding(16, 16, 16, 16); // Set padding here

        rows[0] = new TableRow(this);
        rows[0].addView(roll_tvs[0]);
        rows[0].addView(name_tvs[0]);

        // Add the TextViews for the column numbers to the first row (index 0) of the table
        for (int i = 1; i <= DAY_IN_MONTH; i++) {
            TextView textView = new TextView(this);
            textView.setText(String.valueOf(i));
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
            textView.setPadding(16, 16, 16, 16); // Set padding here
            rows[0].addView(textView); // Add column number TextView to the row
        }
        tableLayout.addView(rows[0]);

        // Populate table data
        for (int i = 1; i < rowSize; i++) {
            rows[i] = new TableRow(this);
            rows[i].setBackgroundColor(i % 2 == 0 ? Color.parseColor("#EEEEEE") : Color.parseColor("#E4E4E4"));

            roll_tvs[i] = new TextView(this);
            roll_tvs[i].setText(String.valueOf(rollArray[i - 1]));
            roll_tvs[i].setPadding(16, 16, 16, 16);

            name_tvs[i] = new TextView(this);
            name_tvs[i].setText(nameArray[i - 1]);
            name_tvs[i].setPadding(16, 16, 16, 16);

            rows[i].addView(roll_tvs[i]);
            rows[i].addView(name_tvs[i]);

            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                TextView textView = new TextView(this);
                String day = String.valueOf(j);
                if (day.length() == 1) day = "0" + day;
                String date = day + "." + month;
                String status = dbHelper.getStatus(idArray[i - 1], date);
                textView.setText(status);
                textView.setPadding(16, 16, 16, 16);
                rows[i].addView(textView);
            }

            tableLayout.addView(rows[i]);
        }
        tableLayout.setShowDividers(TableLayout.SHOW_DIVIDER_MIDDLE);
    }


    private int getDayInMonth(String month) {
        int monthIndex = Integer.parseInt(month.substring(0, 2)) - 1;
        int year = Integer.parseInt(month.substring(3));

        Calendar calendar = Calendar.getInstance();
        calendar.clear(); // Clear the calendar before setting new values
        calendar.set(Calendar.MONTH, monthIndex);
        calendar.set(Calendar.YEAR, year);
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

}
